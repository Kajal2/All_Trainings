var path=require("path");
module.exports = {
    download: (req, res) => {
     
        var joinPath=path.join(__dirname,"../python/Files/",req.query["fileName"]+".csv");
        res.download(joinPath, req.query["fileName"]+'.csv', function(err){

            if(err){
                console.log("error at download service: "+err)
                res.send({
                    msg:err
                })
            }else{
                console.log("downloaded");
            }

        });
        
    }
}
 