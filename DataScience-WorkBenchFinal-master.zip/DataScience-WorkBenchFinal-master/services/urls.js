
module.exports ={
    url: 'http://localhost:1212'
}