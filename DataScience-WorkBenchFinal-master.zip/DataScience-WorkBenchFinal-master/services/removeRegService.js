var mongoose = require('mongoose');
var encode = require('hashcode').hashCode;
var fs = require('fs');
var path=require('path');
module.exports = {
    remove: (req, res) => {
        
        if (req.body.pin === '345678') {
            var trainedModels = require('../models/regTrainedModel.js');
            var TrainedModel = mongoose.model('regtrainedmodels', trainedModels);
            var info={};

            TrainedModel.remove({ _id: req.query.id }, (err, doc) => {
                if (err) {
                   
                   console.log("error at removeRegService mongoDB :"+ err)
                    info = {
                        status: false,
                        msg: err
                    }

                } else {
                    try {
                        var joinPath=path.join(__dirname,"../python/Models/Regression/",req.body.name+".sav");
                        
                        fs.unlinkSync(joinPath);

                        joinPath=path.join(__dirname,"../python/Models/Regression/",req.body.name+"_Failure.sav");

                        fs.unlinkSync(joinPath);

                    } catch (e) {
                        console.log("error at removeRegService while deleting :"+e);
                        
                    }
                    finally {
                        info = {
                            status: true
                        }
                    }
                };
                res.send(info);
                res.end();
            });

        } else {
            console.log("unauthorized");
            res.sendStatus(401);
        }
    }
}