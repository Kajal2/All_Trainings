var mongoose = require('mongoose');
var encode = require('hashcode').hashCode;
var fs = require('fs');
var path=require('path');
module.exports = {
    remove: (req, res) => {
        
        if (req.body.pin === '345678') {
            var trainedModels = require('../models/trainedModel.js');
            var TrainedModel = mongoose.model('trainedmodels', trainedModels);
            var info={};

            TrainedModel.remove({ _id: req.query.id }, (err, doc) => {
                
                if (err) {
                    console.log("error at removeService mongoDB :"+ err)
                    info = {
                        status: false,
                        msg: err
                    }

                } else {
                    try {
                        var joinPath=path.join(__dirname,"../python/Models/Classification/",req.body.name+".sav");
                        
                        fs.unlinkSync(joinPath);

                    } catch (e) {
                        console.log("error at removeService: "+e);
                        
                    }
                    finally {
                        info = {
                            status: true
                        }
                    }
                };
                res.send(info);
                res.end();
            });

        } else {
            console.log("unauthorized");
            res.sendStatus(401);
        }
    }
}