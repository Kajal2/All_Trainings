

var app = angular.module('MachineLearning');

app.controller('TemplateController', ['$scope', '$http', '$rootScope', '$localStorage',
    '$sessionStorage','$state', function ($scope, $http, $rootScope, $localStorage,
        $sessionStorage, $state) {
 
        $rootScope.activeMenu = {"class":""};


        $scope.functionExample = function () {

          
           
        }


$rootScope.classification = false;
$rootScope.regression = false;

$rootScope.applyCSSC = false;
$rootScope.applyRSSC = false;

$scope.showClassification = function ()
{
    if($rootScope.classification == true)
        {
    $rootScope.classification = false;
            $rootScope.applyCSSC = false;
 
    
}

    else if($rootScope.classification == false)
        {
        $rootScope.classification = true;
        $rootScope.regression = false;
        $rootScope.applyCSSC = true;
        $rootScope.applyRSSC = false;
        }
}

$scope.hideNavs = function(){

    $rootScope.applyCSSC = false;
    $rootScope.applyRSSC= false;
}



$scope.goToTraining = function(){
    
        if($rootScope.checkCondition === true)
            {
                if (confirm('Are you sure you want to leave training')) {
    
                    $rootScope.checkCondition = false;
                    $scope.goToTraining();
                 
                } else {
                    return
                }
            }
        else
            {
                $localStorage.templateURL.state = "Training";
                
                window.location = "index";
                
                $rootScope.regression = true;
                
    }
    }
    


    $scope.goToTrainingR = function(){
        
            if($rootScope.checkCondition === true)
                {
                    if (confirm('Are you sure you want to leave training')) {
        
                        $rootScope.checkCondition = false;
                        $scope.goToTrainingR();
                     
                    } else {
                        return
                    }
                }
            else
                {
                    $localStorage.templateURL.state = "regTraining";
                    
                    window.location = "index";
                    
                    $rootScope.regression = true;
                    
        }
        }
        


$scope.goToPredict = function(){
    
        if($rootScope.checkCondition === true)
            {
                if (confirm('Are you sure you want to leave training')) {
    
                    $rootScope.checkCondition = false;
                    $scope.goToPredict();
                 
                } else {
                    return
                }
            }
        else
            {
                $localStorage.templateURL.state = "Predict";
                
                window.location = "index";
                
                $rootScope.regression = true;
                
    }
    }
    


$scope.goToPredictR = function(){

    if($rootScope.checkCondition === true)
        {
            if (confirm('Are you sure you want to leave training')) {

                $rootScope.checkCondition = false;
                $scope.goToPredictR();
             
            } else {
                return
            }
        }
    else
        {
            $localStorage.templateURL.state = "regPredict";
            
            window.location = "index";
            
            $rootScope.regression = true;
            
}
}


$scope.showRegression = function ()
{
    if($rootScope.regression == true)
        {
        $rootScope.regression = false;
        $rootScope.applyRSSC = false;
      
    
    }
    
        else if($scope.regression == false)
            {
            $rootScope.regression = true;
            $rootScope.classification = false;
            $rootScope.applyRSSC = true;
            $rootScope.applyCSSC = false;
    
            }

}
        

        $scope.loadState = function () {

           
            if ($localStorage.templateURL.state === "Training") {
                 $state.go('training');
            }
            else if ($localStorage.templateURL.state === "Predict") {
                 $state.go('predict');
            }
            else if ($localStorage.templateURL.state === "regTraining") {
              
                $state.go('regTraining');
           }
           else if ($localStorage.templateURL.state === "regPredict") {
                  $state.go('regPredict');
                  
           }
            else {
                 $state.go('training');
            }

        }


    
    }])