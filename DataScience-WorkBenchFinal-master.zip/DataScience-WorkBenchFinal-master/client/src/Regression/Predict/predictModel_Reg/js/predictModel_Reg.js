var app = angular.module('MachineLearning');
app.controller('DynamicFormController_Reg', function ($scope, $log, $state, $rootScope, $http, $localStorage) {

    $scope.keys = [];
    $scope.values = {};
    $scope.chartkeys = [];
    $scope.chartvalues = [];
    $scope.failGraphShow = false; 

    $rootScope.applyCSSC = false;
	$rootScope.applyRSSC = true;
    $scope.key = [];
    $scope.toPredict=true;
    $scope.result = [];
    $scope.failFlag=false;
    $scope.attributes = {};
    $scope.data = {};
    $scope.failure={
        "Result":0,
        "graphData":{
            "predictedLine":[],
            "predictedThreshold":[],
            "ThresholdLine":[]

        }
    }
    //     graphData.predictedLine=[];
    // $scope.failure.graphData.predictedThreshold=[];
    // $scope.failure.graphData.ThresholdLine=[];
    var failureBody = {};
    var modelName = "";
    // $scope.chartLikelyData = [];
    // $scope.chartClassifyData = [];
    $scope.result = [];

    $scope.loader = true;

    $scope.startTime=0;
    $scope.threshold=0;

    $scope.predictedInteger = 0;

    $scope.columnPrediction = 0;

    $scope.finalPredict = function (){

        $scope.toPredict=true;
        $scope.failFlag = false;
    }

    $scope.finalFail = function (){
        
                $scope.toPredict=false;
                $scope.flag = false;
            }

            $scope.hideFailGraph = function()
{

$scope.failGraphShow = false;

}


$scope.showFailGraph = function()
{

$scope.failGraphShow = true;
}  


    $scope.showFail_Reg = function (){

       $scope.failGraphShow = false;
        var failureBody = {
            "startTime":$scope.startTime,
            "threshold":$scope.threshold
        };
        $scope.loader = true;

        $http({
            url: '/regression/failure?modelName=' + $scope.model.name,
            method: 'POST',
            data: failureBody,
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Basic c3BhbmRhbmFiOnNwYW5kYW5hYg==' }
        }).then(function (response) {
            $scope.loader = false;
            if (response.data.status) {

                $scope.failFlag = true;
                $scope.failure=response.data.body;
                $scope.failureGraph();
            }
            else {
                toastr.options.timeOut = 8000;
                toastr.error(response.data.msg);
                console.log(response.data.msg);
            }
        }, function (err) {
            $scope.loader = false;
            toastr.options.timeOut = 8000;
            toastr.error(err.data);
            console.log(err); // *****************************************************************************
        });


    }





    $scope.goBack_Reg = function () {
        $rootScope.predctTabColor_Reg.selectModal_Reg = "selectModalU_Reg";
        $rootScope.predctTabColor_Reg.predictModal_Reg = ""
        $state.go('regPredict.selectModel_Reg');
    }

    $http({
        url: '/regression/getModel?model_id=' + $localStorage.modelId,
        method: 'GET'
    }).then(function (response) {
        //$scope.data = response.data.model.predictData;
        console.log(response.data);
        $scope.loader = false;
        if (response.data.status == true) {

            var jsonString = {};
            jsonString = JSON.stringify(eval('(' + response.data.model.predictData + ')'));
            jsonString = JSON.parse(jsonString);
            $scope.model = response.data.model;
            modelName = $scope.model.name;//response.data.model.name;
            console.log(jsonString);
            $scope.data = jsonString;

            $scope.display();
        } else {
            toastr.options.timeOut = 8000;
            toastr.error(response.data.msg);
        }
    }, function (err) {
        $scope.loader = false;
        toastr.options.timeOut = 8000;
        toastr.error(err.data);
        console.log(err);
    });


    $scope.hidePrediction = function (){

        $scope.flag=false;
    
    }


    $scope.floatValues;

    $scope.showPredict = function (){


        
         var predictBody = {}
        console.log("(((((())))))");
        console.log($scope.result);
        for (var index = 0; index < $scope.result.length; index++) {
            $scope.floatValues = parseFloat($scope.result[index].values);
            predictBody[$scope.result[index].keys] = $scope.floatValues;
        }
        $scope.loader = true;
        // $scope.chartLikelyData = [];
        // $scope.chartClassifyData = [];
        console.log($scope.data);
        $http({
            url: '/regression/predict?modelName=' + $scope.model.name,
            method: 'POST',
            data: predictBody,
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Basic c3BhbmRhbmFiOnNwYW5kYW5hYg==' }
        }).then(function (response) {
            $scope.loader = false;
            console.log(response.data.status);
            
            if (response.data.status) {
                $scope.flag = true;
                $scope.predict = response.data.body;
                $scope.predictedInteger=response.data.body.Result;
                $scope.columnPrediction = response.data.body.column;
            
            }
            else {
                toastr.options.timeOut = 8000;
                toastr.error(response.data.msg);
                console.log(response.data.msg);
            }
        }, function (err) {
            $scope.loader = false;
            toastr.options.timeOut = 8000;
            toastr.error(err.data);
            console.log(err); // *****************************************************************************
        });
    }

    $scope.display = function () {
        console.log("display called");
        for (var keys in $scope.data) {
            if (keys === "Result") {
                continue;
            } else {
                $scope.attributes = {
                    keys: keys,
                    values: $scope.data[keys]
                }
                $scope.result.push($scope.attributes);
            }


        }
    }

    $scope.flag = false;





$scope.failureGraph=function(){

    Highcharts.chart('containerPredict', {
        chart:{
            height: 260,
        },
            title: {
                text: null
            },
             credits: {
                    enabled: false
                },
            subtitle: {
                text: null
            },
        
            yAxis: {
                title: {
                    text: null
                }
            },
            plotOptions: {
                series: {
                    label: {
                        connectorAllowed: false
                    },
                    pointStart: 2010
                }
            },
        
            series: [{
                name: "PredictedLine",
                data:$scope.failure.graphData.predictedThreshold
                
            },
        {
            name: "ActualLine",
            data:$scope.failure.graphData.predictedLine

        },{
            name: "ThresholdLine",
            data:$scope.failure.graphData.ThresholdLine

        }],
        
            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 500
                    },
                    chartOptions: {
                        legend: {
                            layout: 'horizontal',
                            align: 'center',
                            verticalAlign: 'bottom'
                        }
                    }
                }]
            }
        
        });

}


















});
app.directive('numbersOnly', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }            
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});