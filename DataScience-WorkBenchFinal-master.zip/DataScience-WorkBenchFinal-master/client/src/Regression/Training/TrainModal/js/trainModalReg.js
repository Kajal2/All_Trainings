var app = angular.module('MachineLearning');

app.controller('TrainModalCtrl_Reg', ['$scope', '$rootScope', '$state', '$http', '$localStorage', function ($scope, $rootScope, $state, $http, $localStorage) {

    
    $scope.savedDegree = 2;

    $rootScope.applyCSSC = false;
	$rootScope.applyRSSC = true;
   

    $scope.outside = true;

    $scope.degreeChange =  false;

    $scope.slider = {
        value: -99,
        options: {
          floor: 1,
          ceil: 5,
          showTicks: true
        }
      };


    
    $scope.linearflag = false;
    $scope.nlinearflag = false;
    $scope.loader = true;
    $scope.goBack = function () {
        $rootScope.tabColor.trainModel = "";
        $rootScope.tabColor.selectAttribute = "attributeSelectionU";
        $state.go('regTraining.attReg');
    }

 $scope.hideAll=false;
    


    $scope.modelName = '';
    $scope.message = true;
    $scope.message1 = false;
    $scope.selectedDegree = 0 ;


    var selectedClassifierName = "";
    $scope.disabledModel = true;
    $scope.trainModalDisable = true;
    $scope.showAccuracy = true;
    $scope.cancelButton = false;


    

    $scope.applyCss = function (index, classifierName) {
    
        $scope.id = index;

      

        $scope.trainModalDisable = false;
        selectedClassifierName = classifierName;
    };

    $scope.cancelTraining = function () {
        $scope.showAccuracy = true;
        $scope.id = -999;
        $scope.cancelButton = false;

    }


$scope.goneBack = false;

$scope.goBackHide = function(){


    $scope.hideAll =  false;
    $scope.outside = true;
    $scope.slider.value = $scope.trainedModel.degree;
    $scope.goneBack = true;
    
}

  
    $http({
        method: "GET",
        url: "/regression/getRegTypes"
    }).then(function (response) {
        //console.log(response.data);
        $scope.loader = false;
        if (response.data.status == true) {
            $scope.classifiers = response.data.regtypes;
            //console.log("HIIIIII" + $scope.attributeData);
            //$scope.showGraph();
            //console.log("This is the variable  " + $scope.attributeData);

        } else {

            toastr.options.timeOut = 8000;
            toastr.error(response.data.msg);
        }


    }, function (err) {
        $scope.loader = false;
        toastr.options.timeOut = 8000;
        toastr.error(err.data);
        console.log(err);
    });

    $scope.getModels = function () {
        $scope.loader = true;
        $http({

            url: '/regression/getTrainedModels',
            dataType: 'json',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        }).then(function (response) {
            $scope.loader = false;
            if (response.data.status == true) {
                console.log(response.data.models);
                $scope.existedModels = response.data.models;

            } else {
                toastr.options.timeOut = 8000;
                toastr.error(response.data.msg);
            }

            //    console.log(response.data.models[0]);
            //    console.log($scope.modelDetails);

        }, function (err) {
            $scope.loader = false;
            toastr.options.timeOut = 8000;
            toastr.error(err);
            console.log(err); // *****************************************************************************
        });
    }

    $scope.trainModel = function () {

        if($scope.id === 0)
            $scope.degreeChange = false;
    
        else 
            $scope.degreeChange = true;   



        $scope.loader = true;
        $scope.disabledModel = true;
        $scope.trainModalDisable = true;
        $scope.cancelButton = true;

        $http({
            method: "GET",
            url: "/regression/trainModel?regressionType=" + selectedClassifierName + "&userId=" + $localStorage.userId,
            headers: {'Authorization': 'Basic c3BhbmRhbmFiOnNwYW5kYW5hYg==' }

        }).then(function (response) {
            $scope.loader = false;
            //console.log(response.data);
            if (response.data.status == true) {
                $scope.trainedModel = response.data.body;
                $scope.degreeAcc = $scope.trainedModel.accuracy.toFixed(2);;
                
                console.log("%%%%%%%%");
                console.log($scope.trainedModel);

                $scope.showAccuracy = false;
                $scope.getModels();
                //console.log("HIIIIII" + $scope.attributeData);
                //$scope.showGraph();
                //console.log("This is the variable  " + $scope.attributeData);

            } else {
                $scope.showAccuracy = true;
                toastr.options.timeOut = 8000;
                toastr.error(response.data.msg);
            }


        }, function (err) {
            $scope.loader = false;
            $scope.showAccuracy = true;
            toastr.options.timeOut = 8000;
            toastr.error(err.data);
            console.log(err);
        });
    }


   

    $scope.saveModel = function () {

        $scope.loader = true;
        $http({
            method: "POST",
            url: "/regression/save?modelName=" + $scope.modelName + '&userId=' + $localStorage.userId,
            data: $scope.trainedModel,
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Basic c3BhbmRhbmFiOnNwYW5kYW5hYg==' }
        }).then(function (response) {
            //console.log(response.data);
            $scope.loader = false;
            if (response.data.status == true) {
                 $state.go('regPredict.selectModel_Reg');
                toastr.options.timeOut = 8000;
                toastr.success("Model saved successfully");


            } else {

                $scope.modelName = '';
                toastr.options.timeOut = 8000;
                toastr.error(response.data.msg);
            }


        }, function (err) {
            $scope.loader = false;
            toastr.options.timeOut = 8000;
            toastr.error(err.data);
            console.log(err);
        });



    }


    $scope.$watch('trainedModel.degree', function (newValue, oldValue) {
        
        $scope.slider.value = newValue;
        $scope.selectedDegree = newValue - 1;
        $scope.showScatterGraph();
        $scope.saveDegree();


    });
    


    $scope.$watch('slider.value', function (newValue, oldValue) {
        if($scope.slider.value == -99)
            {
                return;
            }
            else{
                if($scope.slider.value == $scope.trainedModel.degree && $scope.goneBack == true )
                    {
                        $scope.goneBack = true;
                        return;
                    }
                    else{

     $scope.selectedDegree = $scope.slider.value - 1;
     
     $scope.showScatterGraph(); 
                    }
    }
       

    });


    $scope.saveDegree = function () {
         $scope.outside = true;

        $scope.savedDegree = $scope.slider.value;
        //$scope.hideAll = false;
        $http({
            method: "GET",
            url: "/regression/saveDegree?degree=" + $scope.savedDegree + "&userId=" + $localStorage.userId

        }).then(function (response) {
            $scope.loader = false;
            //console.log(response.data);
            if (response.data.status == true) {
                
                $scope.hideAll = false;
                $scope.trainedModel["degree"]=$scope.savedDegree;
                $scope.trainedModel["accuracy"]=$scope.degreeAcc;
                //console.log("HIIIIII" + $scope.attributeData);
                //$scope.showGraph();
                //console.log("This is the variable  " + $scope.attributeData);

            } else {
                
                toastr.options.timeOut = 8000;
                toastr.error(response.data.msg);
            }


        }, function (err) {
            $scope.loader = false;
            toastr.options.timeOut = 8000;
            toastr.error(err.data);
            console.log(err);
        });
    }


    $scope.showScatterGraphPre = function(){

        $scope.outside = false;
        $scope.showScatterGraph();

        
    }


    $scope.checkModel = function () {

        if ($scope.existedModels.length == 0) {
            $scope.message = false;
        } else {
            for (var index = 0; index < $scope.existedModels.length; index++) {
                if ($scope.modelName == '') {
                    $scope.message = true;
                    break;
                } else {
                    if ($scope.modelName.toLowerCase() === $scope.existedModels[index].name.toLowerCase()) {
                        $scope.message = true;
                        $scope.message1 = true;
                        break;
                    } else {
                        $scope.message = false;
                        $scope.message1 = false;
                    }
                }


            }
        }



    }
    
    $scope.chartDataScatterN = [];
    $scope.chartDataScatter = [];
  
    
        $scope.showScatterGraph = function () {
           

            if($scope.slider.value == -99)
                {
            $scope.slider.value = $scope.trainedModel.degree;
                }
            $scope.chartDataScatter = [];
            if($scope.outside === false)
                {
                $scope.hideAll=true;
                }
             
            if($scope.id == 0)
                {
                $scope.linearflag = true;
                $scope.nlinearflag = false;
                }
            else
                {
                $scope.nlinearflag = true;
                $scope.linearflag = false;    
                }
    
    if($scope.linearflag == true){
        
            angular.forEach($scope.trainedModel.graphData, function (value, key) {
           
                
    
                $scope.highChartOptions = {
    
                    credits: {
                        enabled: false
                    },
    
                    exporting: {
                        enabled: false
                    },
    
                    chart: {
                        plotBackgroundColor: null,
                        plotBorderWidth: 0,
                        plotShadow: false,
                        backgroundColor: null,
                        type: 'scatter',
                        zoomType: 'xy'
                    },
                    title: {
    
                        text: value.name
                    },
                    subtitle: {
                        text: ''
                    },
                    xAxis: {
                        title: {
                            enabled: true,
                            text: ''
                        },
                        startOnTick: true,
                        endOnTick: true,
                        showLastLabel: true
                    },
                    yAxis: {
                        title: {
                            text: ''
                        }
                    },
                    plotOptions: {
                        scatter: {
                            marker: {
                                radius: 5,
                                states: {
                                    hover: {
                                        enabled: true,
                                        lineColor: 'rgb(100,100,100)'
                                    }
                                }
                            },
                            states: {
                                hover: {
                                    marker: {
                                        enabled: false
                                    }
                                }
                            },
                            tooltip: {
                                headerFormat: '<b>{series.name}</b><br>',
                                pointFormat: '{point.x} , {point.y} '
                            }
                        }
                    },
                    series: [{
                        name: "Actual Value",
                        color: value.originalcolor,
                        data: value.originalData
                       
                    }, {
                        name: "Predicted Value",
                        color: value.predictedcolor,
                        data: value.predictedData
                       
                    }]
                }
                $scope.chartDataScatter.push($scope.highChartOptions);
    
    
    
            });
        }
        else
            {
                
                $scope.chartDataScatterN = [];

                angular.forEach($scope.trainedModel.graphData, function (value, key) {
                    
               
             
                         $scope.highChartOptions = {
                            attributeName: value.predictedData[$scope.selectedDegree].Accuracy,
             
                             credits: {
                                 enabled: false
                             },
             
                             exporting: {
                                 enabled: false
                             },
             
                             chart: {
                                 plotBackgroundColor: null,
                                 plotBorderWidth: 0,
                                 plotShadow: false,
                                 backgroundColor: null,
                                 type: 'scatter',
                                 zoomType: 'xy'
                             },
                             title: {
             
                                 text: value.name
                             },
                             subtitle: {
                                 text: ''
                             },
                             xAxis: {
                                 title: {
                                     enabled: true,
                                     text: ''
                                 },
                                 startOnTick: true,
                                 endOnTick: true,
                                 showLastLabel: true
                             },
                             yAxis: {
                                 title: {
                                     text: ''
                                 }
                             },
                             plotOptions: {
                                 scatter: {
                                     marker: {
                                         radius: 5,
                                         states: {
                                             hover: {
                                                 enabled: true,
                                                 lineColor: 'rgb(100,100,100)'
                                             }
                                         }
                                     },
                                     states: {
                                         hover: {
                                             marker: {
                                                 enabled: false
                                             }
                                         }
                                     },
                                     tooltip: {
                                         headerFormat: '<b>{series.name}</b><br>',
                                         pointFormat: '{point.x} , {point.y} '
                                     }
                                 }
                             },
                             series: [{
                                 name: "Actual Value",
                                 color: value.originalcolor,
                                 data: value.originalData
                                
                             }, {
                                 name: "Predicted Value",
                                 color: value.predictedcolor,
                                 data: value.predictedData[$scope.selectedDegree].degreeData
                                
                             }]
                         }
                   
                         $scope.degreeAcc = $scope.highChartOptions.attributeName.toFixed(2);;
                         $scope.chartDataScatterN.push($scope.highChartOptions);
             
             
                         
                     });

                     
            }
    
    
        };

      








       /*  $scope.degreeAccuracy = $scope.degreeDataJson.body.graphData.predictedData[$scope.selectedDegree].Accuracy; */
        

}]);