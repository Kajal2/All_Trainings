use strict;

our $string="hello";

sub function1{
	local $string="hello perl";
	function2();
	print "\nInside function1 string contains $string";
}

sub function2{
	print "\nInside function2 string contains $string";
}

function1;
print "\nOutside the functions string contains $string";