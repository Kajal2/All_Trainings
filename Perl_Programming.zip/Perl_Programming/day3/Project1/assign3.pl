use strict;

sub copyfile{
	my $sourcefilename="D:\\Presentation\\Perl\\MyWorkSpace\\Project1\\file2.txt";
	my $newfilename="file4.txt";
	
	open(INPUT,$sourcefilename);
	open(OUTPUT,'>',$newfilename);
	
	while(my $line=<INPUT>){
		$line=~s/has{1,3}/is/;
		print OUTPUT $line;
	}
	
	print "\nDone";
	
	close(INPUT);
	close(OUTPUT);
	
	
}

copyfile;