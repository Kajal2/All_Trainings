use strict;

sub readfile{
	my $filename="D:\\Presentation\\Perl\\MyWorkSpace\\Project1\\file2.txt";
	open(INPUT,$filename);
	
	while(my $ch=getc INPUT){
			print "$ch";
	}
	close(INPUT);
	
}

readfile;