use strict;

my $str="Capgemini has great work culture located in vikhroli, Mumbai";
if($str=~m/has(.*),/){
	print "$1";
}

my $str1="The programming world of perl";

$str1=~m/(m{1})(.*)/;
print "\n$1 \n$2";