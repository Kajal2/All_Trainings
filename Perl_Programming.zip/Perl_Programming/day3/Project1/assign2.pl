use strict;

sub validateemailid{
	my @emails = (
		'john@caveofprogramming.com',
		'hello',
		'@llkj.com',
		'jklj778dd@somewhere77.com',
		'lkjl@7788.',
	);
	
	foreach my $email(@emails){
		if($email=~m/\w+\@\w+\.\w+/){
			print "\nValid email : $email";
		}else{
			print "\nInvalid email : $email";
		}
	}
	
}

validateemailid;