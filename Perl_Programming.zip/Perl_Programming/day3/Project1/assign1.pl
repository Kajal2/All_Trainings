my %month=('01'=>'Jan','02'=>'Feb');
my $pointer=\%month;

print "\niterating over the hash using pointer";

foreach my $i(keys %$pointer){
	print "\n $i $$pointer{$i}";
}

{
	
	print "\nAdding record";
}

{
	print "\nUpdating the record";
}
