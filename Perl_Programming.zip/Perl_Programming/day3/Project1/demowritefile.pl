use strict;

sub writetofile{
	my $filename="file3.txt";
	open(OUTPUT,'>',$filename);
	print OUTPUT "This is file3";
	
	close(OUTPUT);
}

writetofile;