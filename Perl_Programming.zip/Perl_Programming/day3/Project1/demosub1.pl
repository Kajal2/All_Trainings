use strict;

sub greetuser{
	my @users=@_;
	foreach my $user(@users){
		print "\nWelcome $user";
	}
	
	print "\nsecond parameter is $_[1]";
}

sub addnumbers{
	my @numbers=@_;
	my $result=0;
	foreach my $num(@numbers){
		$result=$result+$num;
	}
	return $result;
}
my $output=addnumbers(2,3,4,7);
print "\noutput=$output";

#greetuser('user1','user2','user3');

