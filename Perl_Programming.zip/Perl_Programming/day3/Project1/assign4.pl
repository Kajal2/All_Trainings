my $text="I am 17 years old";

$text=~m/(\d+)/;
#print "$1";

my $text1="The code for the device is GP8765";
$text1=~m/(\w+\d{1,4})/;
print "$1";
