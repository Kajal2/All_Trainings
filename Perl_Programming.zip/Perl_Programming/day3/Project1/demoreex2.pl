use strict;

my $str="hello how are you";

if($str=~m/[aeiou]/){
	print "\nvalid";
}else{
	print "\nInvalid"
}

my $str1="my code is 13";
if($str1=~m/[0-9]/){
	print "\nvalid data";
}else{
	print "\nInvalid data";
}

my $str2="capgemini is great place to work and Capgemini has good work culture";

if($str2=~m/(capgemini|Capgemini|CAPGEMINI)/){
	print "\nvalid string";
}else{
	print "\nInvalid string";
	
}






