sub validatestring{
	my $string="How is you";
	if($string=~m/are/){
		print "\nvalid string";
	}else{
		print "\nInvalid string";
	}
}
sub replacestring{
	my $str="I has tea";
	$str=~s/has/had/;
	print "\n$str";
	
}
replacestring;
