#use 5.010;
use feature 'state';


sub incrementcount{
	state $count=0;
	print "\ncount=$count";
	$count++;
}

incrementcount();		#--0
incrementcount();		#--1
incrementcount();		#--2