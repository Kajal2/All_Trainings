$dirtoget="D:\\Presentation\\Perl\\MyWorkSpace\\Project1";
opendir(IMD, $dirtoget) || die("Cannot open directory");
@thefiles= readdir(IMD);
closedir(IMD);


foreach $files (@thefiles) {
	  print "$files\n";
}