use File::Copy;

my $filename1="D:\\Presentation\\Perl\\MyWorkSpace\\Project1\\file2.txt";
	
#copy($filename1, "dupfile2.txt");
#rename "dupfile2.txt", "duplicate.txt";
unlink "duplicate.txt"; 
print "\ndone";