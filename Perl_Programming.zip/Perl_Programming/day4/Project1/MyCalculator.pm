package MyCalculator;

BEGIN{
	print "\nInside constructor";
}


END{
	print "\nInside destructor";
}
our $name="capgemini";

sub addnumbers{
	my @numbers=@_;
	my $result=0;
	
	foreach my $num(@numbers){
		$result=$result+$num;
	}
	print "\nResult of addition is $result";
	
}

sub mulnumbers{
	print "\nInside mulnumbers subroutine"
}
1;

