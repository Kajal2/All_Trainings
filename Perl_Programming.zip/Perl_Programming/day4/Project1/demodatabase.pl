use strict;
use DBI;

sub addrecord{
	my $driver="mysql";
	my $database="testdb";
	my $dsn="DBI:$driver:database=$database";
	my $userid="root";
	my $password="root";
	
	my $dbh=DBI->connect($dsn,$userid,$password,{AutoCommit=>0});
	#my $sth=$dbh->prepare("insert into user values('12','mumbai','kkr street','Siyana')");
	#$sth->execute();


	my $sth=$dbh->prepare("insert into user values(?,?,?,?)");
	my $id='14';
	my $city='pune';
	my $street='dsouza street';
	my $name='Jack';
	
	$sth->execute($id,$city,$street,$name);


	$sth->finish();
	$dbh->commit;
	print "\nRecord Added";	
}

addrecord;