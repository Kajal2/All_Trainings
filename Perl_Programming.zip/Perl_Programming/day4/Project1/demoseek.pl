use strict;

sub readfile{
	my $filename="D:\\Presentation\\Perl\\MyWorkSpace\\Project1\\file2.txt";
	open(INPUT,$filename);
	seek INPUT,10,0;
	seek INPUT,15,1;
	print tell INPUT;
	
	while(my $line=<INPUT>){
		print "$line";
	}
	close(INPUT);
}
readfile;