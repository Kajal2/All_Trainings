use mysavingaccount;

{
my $obj=mysavingaccount->new("A1",5000);
$obj->withdraw();

my $bal=$obj->getbalance();
print "\nBalance is $bal";

$obj->setbalance(7000);
$bal=$obj->getbalance();
print "\nAfter changing Balance is $bal";

my $typ=$obj->gettype();
print "\nsavingaccount type is $typ";

}
{
	my $obj1=mysavingaccount->new("A2",6000);
	$obj1->withdraw();
	
}

my $obj3=mysavingaccount->new("A3",7000);
$obj3->withdraw();
undef $obj3;

print "\nend of the program";