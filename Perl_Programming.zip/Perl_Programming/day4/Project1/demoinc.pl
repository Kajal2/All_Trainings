foreach my $modname(@INC){
	print "\n$modname";
}