use strict;

sub readfile{
	my $filename="D:\\Presentation\\Perl\\MyWorkSpace\\Project1\\file2.txt";
	open(INPUT,$filename);
	
	
	while(my $line=<INPUT>){
		if($line=~m/(I..a.)(...)/){
			print "\n$1: $2";
		}
	}
	
	#while(my $line=<INPUT>){
	#	if($line=~m/h.s/){
	#		print "$line";
	#	}
	#}
	#while(<INPUT>){
			#print "$_";
	#}
	close(INPUT);
	
}

readfile;