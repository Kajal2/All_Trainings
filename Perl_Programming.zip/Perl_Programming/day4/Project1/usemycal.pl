use MyCalculator;

MyCalculator::addnumbers(2,3,4,6);
my $compname=$MyCalculator::name;

print "\ncompany name is $compname";

print "\nending my code";