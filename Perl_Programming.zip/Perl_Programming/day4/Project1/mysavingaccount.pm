package mysavingaccount;
use myacct;
our @ISA=qw(myacct);

sub new{
	my ($class)=@_;
	#call the constructor of myacct package
	my $self=$class->SUPER::new($_[1],$_[2]);
	#add more attributes
	$self->{type}="regular";
	bless($self,$class);
	#bless($self,"mysavingaccount");
	print "\nInside savingaccount";
	return $self;
}

sub gettype{
	my($self)=@_;
	return $self->{type};
}

sub withdraw{
	print "\ninside saving account withdraw";
}
sub DESTROY{
	print "\nInside Destroy";
}
1;