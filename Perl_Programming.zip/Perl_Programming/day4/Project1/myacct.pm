package myacct;

sub new{
	my $class=shift;
	my $self={
		acctnum=>shift,
		balance=>shift
	};
	bless($self,$class);
	print "\nInside Account";
	return $self;
}

sub getbalance{
	my($self)=@_;
	return $self->{balance};
}

sub setbalance{
	my($self,$newbal)=@_;
	return $self->{balance}=$newbal;
}

sub withdraw{
	print "\nInside Account withdraw";
}
1;