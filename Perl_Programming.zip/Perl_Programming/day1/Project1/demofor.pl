use strict;

print "\nNumbers from 1 to 5";

for(my $num=10;$num>=1;$num--){
	print "\n$num";
}

print "\noutput of foreach";
foreach my $num1(1..5){
	print "\n$num1";
}