use strict;

sub function2{
	our $number=100;
	print "inside function2 number=$number";
}

sub function1{
	print 'hello user';
	print "\nwelcome to perl";
	my $age=20;
	print "\nage =$age";
	my $fname="Pritesh";
	print "\nfname=$fname";
	my $lname="Shah";
	print "\nlname=$lname";
}

function2;
print "\noutside functions number=$main::number";
print "\nPackage name=".__PACKAGE__;


