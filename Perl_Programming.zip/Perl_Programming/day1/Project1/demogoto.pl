print "\nBeg of the program";

#goto OUTER;
print "\nMid of the program";

goto INNER;
print "\nEnd of the program";

INNER:print "\nWelcome";
OUTER:print "\nbye";
