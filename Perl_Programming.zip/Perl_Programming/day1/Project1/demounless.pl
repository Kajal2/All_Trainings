use strict;
my $x=12;

unless($x>4){
	print "\nNumber less then 4";
}elsif($x>2){
	print "\nNumber greater than 2 ";
}else{
	print "\nNumber less than 2";
}
