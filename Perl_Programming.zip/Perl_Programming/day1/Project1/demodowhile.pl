use strict;

my $ctr=15;

print "\nNumber from 1 to 5";

do{
	print "\n".$ctr;
	$ctr++;
}while($ctr<=5);