use strict;

my $age=10;


my $status=($age>18)?"Eligible for voting":"Not eligible";

print "$status";
