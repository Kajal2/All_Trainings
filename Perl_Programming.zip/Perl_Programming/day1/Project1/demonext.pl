use strict;

my $ctr=1;

print "\nOdd Numbers";

while($ctr<=5){
	if($ctr%2==0){
		next;
	}else{
		print "\n".$ctr;
	}

}
continue{
	$ctr++;
}

