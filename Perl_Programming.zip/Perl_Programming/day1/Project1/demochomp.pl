use strict;
my $fname="pravin\n";
my $lname="pawar";
print "hello";
chomp $fname;
print "'$fname'";
print "$lname";

my $str="this is my string";

my $newstring=substr($str,5,5);
print "\noriginal string=$str";
print "\nnewstring=$newstring";


my $para="patni tcomputers";
my $x=index($para,"t",3);
print "\nx=$x";





