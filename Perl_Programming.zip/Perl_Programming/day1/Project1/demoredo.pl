use strict;

my $ctr=0;

while($ctr<10){
	$ctr++;
	print "\n$ctr";
	if($ctr==5){
		print "\n$ctr";
		redo;		
	}
}
