use strict;

my $ctr=1;

print "\nNumber from 1 to 5";

do{
	print "\n".$ctr;
	$ctr++;
}until($ctr>5);