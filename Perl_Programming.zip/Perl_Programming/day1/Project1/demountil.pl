use strict;

my $ctr=1;

print "\nNumber from 1 to 5";

until($ctr>5){
	print "\n".$ctr;
	$ctr++;
}