use strict;
my $x=30;

if($x>4){
	print "\nNumber greater than 4";
}elsif($x>2){
	print "\nNumber greater than 2 but less then 4";
}else{
	print "\nNumber less than 2";
}
