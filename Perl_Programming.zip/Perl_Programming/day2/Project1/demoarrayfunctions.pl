use strict;

my @num=(1,2,3);
print "\nBefore appending num contains @num";

push(@num,(4..6)); #to append data to an existing array

print "\nAfter appending num contains @num";

my $first=shift(@num);
print "\nAfter using shift num contains @num";
print "\nFirst element is $first";

my $last=pop(@num);
print "\nAfter using pop num contains @num";
print "\nLast element is $last";

unshift(@num,(9,10,11));
print "\nAfter prepending num contains @num";

my @slicednum=@num[2,3,4];
print "\nslicednum contains @slicednum";

my @numbers=(1..10);
print "\nnumbers contains @numbers";
splice(@numbers,8,5,19..23);
print "\nAfter splicing numbers contains @numbers";

#sorting an array
my @foods=qw(pizza steak chicken burgers);
my @sortedfoods=sort(@foods);
$[=1;
print "\nfoods[1]=$foods[1]";

#print "\nfoods array contains @foods";
#print "\nsortedfoods array contains @sortedfoods";

my @oddnumbers=(1,3,5);
my @evennumbers=(2,4,6);
my @oddeven=(@oddnumbers,@evennumbers);
print "\noddeven array contains @oddeven";
























