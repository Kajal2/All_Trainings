use strict;
my %discount=('mon',5,'tue',6,'wed',7);
print "\nDiscount for tuesday is $discount{'tue'}";

my %skillpoints=('basic'=>4,'medium'=>5,'advance'=>10);
print "\nskill point for medium is $skillpoints{'medium'}";

#my @skillarray=@skillpoints{'basic','medium','advance'};
my @skillarray=values %skillpoints;
print "\nskillarray contains @skillarray";
my @skillkeys=keys %skillpoints;
print "\nskillkeys contains @skillkeys";



