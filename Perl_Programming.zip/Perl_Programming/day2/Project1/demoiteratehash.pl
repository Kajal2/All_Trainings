use strict;
my %gradehash=('PM'=>4,'ML'=>5,'VP'=>2);
my $size=keys %gradehash;
print "\nsize=$size";

#for(keys %gradehash){
#	print "\n$gradehash{$_}";
#}


print "\nEnter your grade";
my $grade=<STDIN>;
chomp $grade;

if(exists($gradehash{$grade})){
	print "\nGrade exists in the organization";
}else{
	print "\nGrade does not exists";
}

$gradehash{'CEO'}=13; #appending a new key value pair 
while((my $key,my $val)=each(%gradehash)){
	print "\n".$key."=".$val;
}
print "\nAfter removing CEO key";
delete $gradehash{'CEO'};
while((my $key,my $val)=each(%gradehash)){
	print "\n".$key."=".$val;
}


#undef %gradehash;
if(%gradehash){
	print "\nDefined";
}else{
	print "\nUndefined";
}
