use strict;

my @products=('keyobard','monitor','mouse','computer');

for my $product(@products){
	print "\n$product";
}

my @numbers=qw(one two three four);
print "\nData inside numbers array is ";

my $ctr=0;
while($numbers[$ctr]){
	print "\n$numbers[$ctr]";
	$ctr++;
}
