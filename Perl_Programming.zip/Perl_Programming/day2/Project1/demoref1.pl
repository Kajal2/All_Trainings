use strict;

my $x=5;
my $xref=\$x;

my @num=(1,2,3,4,5);
my $numref=\@num;

my %skillpoints=('basic'=>4,'medium'=>5,'advance'=>10);
my $skillref=\%skillpoints;

#print "\nvalue where xref points is $$xref";
#print "\nnumref contains @$numref";


print "\nskillref contains ".$skillref->{'basic'};



