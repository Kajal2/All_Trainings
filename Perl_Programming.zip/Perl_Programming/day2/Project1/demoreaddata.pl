print "\nEnter your name";
my $name=<STDIN>;
print "Name = $name";
