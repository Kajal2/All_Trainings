use strict;

#creating an array
my @products=('Keyboard','monitor','mouse','computer');
my @numbers=(1,2,3,4,5);
my @country=(1,"India",2,"USA",3,"UK");
my @cities=qw/mumbai pune banagalore/;


print "\n$products[0]";
print "\n$numbers[3]";
print "\n$cities[1]";

#finding size of the array
my $abcd=@products;
print "\nSize of products array=$abcd";

#duplicating an array
my @dupproducts=@products;
print "\n$dupproducts[0]";

#using range operator
my @num=(1..3);
my @char=('a'..'g');
print "\n@num";
print "\n@products";
print "\n@char";






