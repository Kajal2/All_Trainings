#Pls ensure the the excel file is there in the working dir otherwise, need to specify the path for this excel file
import sys
sys.path.append('C:\\Users\karamana\\AppData\\Local\\Programs\\Python\Python36-32\\jdcal-1.3\jdcal-1.3')
sys.path.append('C:\\Users\karamana\\AppData\\Local\\Programs\\Python\\Python36-32\\et_xmlfile-1.0.1')
sys.path.append('C:\\Users\karamana\\AppData\\Local\\Programs\\Python\\Python36-32\\openpyxl-2.5.0a3')
import openpyxl
#wb = Workbook()
wb=openpyxl.load_workbook('Sample.xlsx')
sheet = wb.active #wb.get_sheet_by_name('Sheet1')
col1 = sheet['A1']
print ("A1 value is", col1.value)
c = sheet['B1']
print ('Row ' + str(c.row) + ', Column ' + c.column + ' is ' + c.value)
print ('Cell ' + c.coordinate + ' is ' + c.value)
print ("All the values")
for i in range(1, sheet.max_row):
    print(i, sheet.cell(row=i, column=2).value)
print ("Max rows:", sheet.max_row)
print ("Max Cols:", sheet.max_column)
print ("Thank you")
