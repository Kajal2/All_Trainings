angular.module('filterApp',[])

.filter("concatNationCode",function(){
	
	return function(item){
		return"+91"+item;
	}
})

.controller('FilterController', function($scope,$filter) {
	 $scope.guests = 
		[
			{
				"guestId":101,
				"guestName":"Anil",
				"contactNumber":"8645635092"
			},
			{
				"guestId":102,
				"guestName":"Ganesh",
				"contactNumber":"9946945634"
			},
			{
				"guestId":103,
				"guestName":"Karthik",
				"contactNumber":"9986173092"
			},
			{
				"guestId":104,
				"guestName":"Shashank",
				"contactNumber":"9986464892"
			},
			{
				"guestId":105,
				"guestName":"Abishek",
				"contactNumber":"9958659892"
			},
			{
				"guestId":106,
				"guestName":"Nachiket",
				"contactNumber":"8997358092"
			},
			{
				"guestId":107,
				"guestName":"Vaishali",
				"contactNumber":"9739179037"
			}
		];
		$scope.sortColumn = "+guestId";
});


