var qmodule=angular.module("myapp",[]);
qmodule.factory("EmployeeService",function($http,$q){
	
	return {
		retriveGuest:function(){
		var def=$q.defer();
		$http({
			method:'GET',
			url:"EmployeeData.json"
		}).success(function(data,status,header,config){
			def.resolve(data);
		}).error(function(data,status,header,config){
			def.reject(status);
		});
		return def.promise;		
	}
});