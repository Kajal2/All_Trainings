var mymodule=angular.module("DirectiveApp",[]);

//directive as a element
mymodule.directive("helloworldelement",function(){
	return{
		restrict:'E',
		template:"Hello World Element from directive"
	}
	
});

//directive as a attribute
mymodule.directive("helloworldattribute",function(){
	return{
		restrict:'A',
		template:"Hello World Attribute from directive"
	}
	
});

//directive as a Class
mymodule.directive("helloworldclass",function(){
	return{
		restrict:'C',
		template:"Hello World class from directive"
	}
	
});

//directive as a Comment
mymodule.directive("helloworldcomment",function(){
	return{
		restrict:'M',
		replace:true,
		template:"<h4>Hello World comment from directive</h4>"
	}
	
});

//directive as element as well as attribute
mymodule.directive("helloworldelementattribute",function(){
	return{
		restrict:'EA',
		
		template:"Hello World element and attribute from directive"
	}
	
});
