var app=angular.module("RouteApp",['ngRoute']);
app.config(function($routeProvider,$locationProvider){
	$routeProvider.when('/',{
		template:"<h1>Welcome Route</h1>"
		
	}).
	when('/state',{
		template:"<h2>Maharashtra</h2>"
	}).
	when('/state/city',{
		template:"<h1>Mumbai</h1>"
	}).
	when('/country',{
		template:"<h1>India</h1>"
	}).
	when('/employee',{
		templateUrl:"employeeHome.html";
		controller:"EmployeeController"
		
		
	}).
	otherwise({
		redirectTo:"/"
	})
});

app.controller("EmployeeController",function($scope){
	$scope.id=101;
	$scope.name="Raj";
	$scope.salary=45000;
	
});