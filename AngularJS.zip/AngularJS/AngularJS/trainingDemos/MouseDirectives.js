var mymodule=angular.module("Customedirective",[]);

mymodule.directive("mousentry",function(){
	return{
	link:function(scope,element,attrs){
		element.bind("mouseenter",function(){
			element.addClass(attrs.datastyle);
		});
	}
	}

});

mymodule.directive("mouseleft",function(){
	return{
	link:function(scope,element,attrs){
		element.bind("mouseleave",function(){
			element.removeClass(attrs.datastyle);
		});
	}
	}

});