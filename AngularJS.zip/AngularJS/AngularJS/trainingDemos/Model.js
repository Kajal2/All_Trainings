var app=angular.module("myfirst",[]);
	app.controller("HelloWorldController",function($scope){
	$scope.greetingmessage="welcome to angular world";
	$scope.employee={"id":121388,"name":"kajal","salary":50000};
	$scope.guests=[
	{"guestId":101,"GuestName":"Kanika","GuestContactNumber":"9757347384"},
	{"guestId":102,"GuestName":"Swathi","GuestContactNumber":"9757547344"},
	{"guestId":103,"GuestName":"Sakshi","GuestContactNumber":"9757547322"}
	];
	});